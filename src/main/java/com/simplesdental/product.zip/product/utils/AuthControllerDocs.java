package com.simplesdental.product.utils;

import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.examples.Example;
import io.swagger.v3.oas.models.parameters.RequestBody;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import io.swagger.v3.oas.models.security.SecurityRequirement;

import java.util.Collections;

/**
 * Classe para definir a documentação Swagger do AuthController
 * Usa exclusivamente classes do pacote io.swagger.v3.oas.models
 */
public class AuthControllerDocs {

    public static final class Login {
        public static Operation operation() {
            // Criar exemplo de credenciais
            Example credentialsExample = new Example()
                    .description("Exemplo básico de credenciais")
                    .value("{\n  \"email\": \"usuario@exemplo.com\",\n  \"password\": \"senha123\"\n}");

            // Criar exemplo de resposta bem-sucedida
            Example successResponseExample = new Example()
                    .description("Exemplo de resposta bem-sucedida")
                    .value("{\n  \"token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...\",\n  \"user\": {\n    \"id\": 1,\n    \"name\": \"João Silva\",\n    \"email\": \"usuario@exemplo.com\",\n    \"role\": \"user\"\n  }\n}");

            // Criar exemplo de credenciais inválidas
            Example invalidCredentialsExample = new Example()
                    .description("Credenciais inválidas")
                    .value("{\n  \"status\": 401,\n  \"message\": \"Falha na autenticação: Credenciais inválidas\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}");

            // Schema para request
            Schema<?> requestSchema = new Schema<>()
                    .$ref("#/components/schemas/AuthRequestDTO");

            // Schema para response
            Schema<?> responseSchema = new Schema<>()
                    .$ref("#/components/schemas/AuthResponseDTO");

            // Schema para erro
            Schema<?> errorSchema = new Schema<>()
                    .$ref("#/components/schemas/ExceptionResponseDTO");

            // Criar o content para request body
            MediaType requestMediaType = new MediaType()
                    .schema(requestSchema)
                    .addExamples("Exemplo de Credenciais", credentialsExample);

            // Criar request body
            RequestBody requestBody = new RequestBody()
                    .description("Credenciais de login do usuário")
                    .required(true)
                    .content(new Content().addMediaType("application/json", requestMediaType));

            // Criar content para resposta 200
            MediaType successMediaType = new MediaType()
                    .schema(responseSchema)
                    .addExamples("Resposta de Sucesso", successResponseExample);

            // Criar content para resposta 401
            MediaType unauthorizedMediaType = new MediaType()
                    .schema(errorSchema)
                    .addExamples("default", invalidCredentialsExample);

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("200", new ApiResponse()
                            .description("Login realizado com sucesso")
                            .content(new Content().addMediaType("application/json", successMediaType)))
                    .addApiResponse("401", new ApiResponse()
                            .description("Credenciais inválidas")
                            .content(new Content().addMediaType("application/json", unauthorizedMediaType)));

            // Criar e retornar a operação
            return new Operation()
                    .summary("Autenticação de Usuário")
                    .description("Realiza login e retorna token JWT para ser utilizado nas requisições subsequentes")
                    .tags(Collections.singletonList("Autenticação"))
                    .requestBody(requestBody)
                    .responses(responses);
        }
    }

    public static final class Register {
        public static Operation operation() {
            // Criar exemplo de registro
            Example registerExample = new Example()
                    .description("Exemplo de registro de usuário")
                    .value("{\n  \"name\": \"João Silva\",\n  \"email\": \"joao.silva@exemplo.com\",\n  \"password\": \"Senha@123\"\n}");

            // Criar exemplo de resposta bem-sucedida
            Example successResponseExample = new Example()
                    .description("Exemplo de resposta bem-sucedida")
                    .value("{\n  \"token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...\",\n  \"user\": {\n    \"id\": 1,\n    \"name\": \"João Silva\",\n    \"email\": \"joao.silva@exemplo.com\",\n    \"role\": \"user\"\n  }\n}");

            // Criar exemplo de email já em uso
            Example emailInUseExample = new Example()
                    .description("Email já em uso")
                    .value("{\n  \"status\": 400,\n  \"message\": \"Falha no registro: Email já está em uso\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}");

            // Schema para request
            Schema<?> requestSchema = new Schema<>()
                    .$ref("#/components/schemas/RegisterRequestDTO");

            // Schema para response
            Schema<?> responseSchema = new Schema<>()
                    .$ref("#/components/schemas/AuthResponseDTO");

            // Schema para erro
            Schema<?> errorSchema = new Schema<>()
                    .$ref("#/components/schemas/ExceptionResponseDTO");

            // Criar o content para request body
            MediaType requestMediaType = new MediaType()
                    .schema(requestSchema)
                    .addExamples("Registro Básico", registerExample);

            // Criar request body
            RequestBody requestBody = new RequestBody()
                    .description("Informações do novo usuário")
                    .required(true)
                    .content(new Content().addMediaType("application/json", requestMediaType));

            // Criar content para resposta 200
            MediaType successMediaType = new MediaType()
                    .schema(responseSchema)
                    .addExamples("Resposta de Sucesso", successResponseExample);

            // Criar content para resposta 400
            MediaType badRequestMediaType = new MediaType()
                    .schema(errorSchema)
                    .addExamples("default", emailInUseExample);

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("200", new ApiResponse()
                            .description("Usuário registrado com sucesso")
                            .content(new Content().addMediaType("application/json", successMediaType)))
                    .addApiResponse("400", new ApiResponse()
                            .description("Informações inválidas para registro")
                            .content(new Content().addMediaType("application/json", badRequestMediaType)));

            // Criar e retornar a operação
            return new Operation()
                    .summary("Registro de Novo Usuário")
                    .description("Cria um novo usuário no sistema e retorna token JWT")
                    .tags(Collections.singletonList("Autenticação"))
                    .requestBody(requestBody)
                    .responses(responses);
        }
    }

    public static final class GetUserContext {
        public static Operation operation() {
            // Criar exemplo de contexto do usuário
            Example userContextExample = new Example()
                    .description("Informações do usuário logado")
                    .value("{\n  \"id\": 1,\n  \"name\": \"João Silva\",\n  \"email\": \"joao.silva@exemplo.com\",\n  \"role\": \"user\"\n}");

            // Schema para resposta
            Schema<?> responseSchema = new Schema<>()
                    .$ref("#/components/schemas/UserDTO");

            // Schema para erro
            Schema<?> errorSchema = new Schema<>()
                    .$ref("#/components/schemas/ExceptionResponseDTO");

            // Criar content para resposta 200
            MediaType successMediaType = new MediaType()
                    .schema(responseSchema)
                    .addExamples("Contexto do Usuário", userContextExample);

            // Criar content para erros
            MediaType errorMediaType = new MediaType()
                    .schema(errorSchema);

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("200", new ApiResponse()
                            .description("Contexto do usuário recuperado com sucesso")
                            .content(new Content().addMediaType("application/json", successMediaType)))
                    .addApiResponse("401", new ApiResponse()
                            .description("Não autenticado")
                            .content(new Content().addMediaType("application/json", errorMediaType)))
                    .addApiResponse("403", new ApiResponse()
                            .description("Sem permissão para acessar este recurso")
                            .content(new Content().addMediaType("application/json", errorMediaType)));

            // Criar requisito de segurança
            SecurityRequirement security = new SecurityRequirement().addList("bearerAuth");

            // Criar e retornar a operação
            return new Operation()
                    .summary("Obter Contexto do Usuário")
                    .description("Recupera informações do usuário autenticado na sessão atual")
                    .tags(Collections.singletonList("Autenticação"))
                    .security(Collections.singletonList(security))
                    .responses(responses);
        }
    }

    public static final class UpdatePassword {
        public static Operation operation() {
            // Criar exemplo de atualização de senha
            Example passwordUpdateExample = new Example()
                    .description("Exemplo de atualização de senha")
                    .value("{\n  \"currentPassword\": \"senhaAtual123\",\n  \"newPassword\": \"novaSenha123\"\n}");

            // Criar exemplo de resposta de sucesso
            Example successResponseExample = new Example()
                    .description("Resposta de sucesso")
                    .value("\"Senha atualizada com sucesso\"");

            // Criar exemplo de senha atual incorreta
            Example incorrectPasswordExample = new Example()
                    .description("Senha atual incorreta")
                    .value("{\n  \"status\": 400,\n  \"message\": \"Erro ao atualizar senha: Senha atual incorreta\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}");

            // Schema para request
            Schema<?> requestSchema = new Schema<>()
                    .$ref("#/components/schemas/PasswordUpdateDTO");

            // Schema para erro
            Schema<?> errorSchema = new Schema<>()
                    .$ref("#/components/schemas/ExceptionResponseDTO");

            // Criar o content para request body
            MediaType requestMediaType = new MediaType()
                    .schema(requestSchema)
                    .addExamples("Atualização de Senha", passwordUpdateExample);

            // Criar request body
            RequestBody requestBody = new RequestBody()
                    .description("Senhas atual e nova")
                    .required(true)
                    .content(new Content().addMediaType("application/json", requestMediaType));

            // Criar content para resposta 200
            MediaType successMediaType = new MediaType()
                    .addExamples("default", successResponseExample);

            // Criar content para resposta 400
            MediaType badRequestMediaType = new MediaType()
                    .schema(errorSchema)
                    .addExamples("default", incorrectPasswordExample);

            // Criar content para resposta 401
            MediaType unauthorizedMediaType = new MediaType()
                    .schema(errorSchema);

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("200", new ApiResponse()
                            .description("Senha atualizada com sucesso")
                            .content(new Content().addMediaType("application/json", successMediaType)))
                    .addApiResponse("400", new ApiResponse()
                            .description("Senha atual incorreta ou nova senha inválida")
                            .content(new Content().addMediaType("application/json", badRequestMediaType)))
                    .addApiResponse("401", new ApiResponse()
                            .description("Não autenticado")
                            .content(new Content().addMediaType("application/json", unauthorizedMediaType)));

            // Criar requisito de segurança
            SecurityRequirement security = new SecurityRequirement().addList("bearerAuth");

            // Criar e retornar a operação
            return new Operation()
                    .summary("Atualizar Senha")
                    .description("Atualiza a senha do usuário autenticado")
                    .tags(Collections.singletonList("Autenticação"))
                    .security(Collections.singletonList(security))
                    .requestBody(requestBody)
                    .responses(responses);
        }
    }
}