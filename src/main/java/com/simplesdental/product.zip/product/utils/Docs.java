package com.simplesdental.product.utils;

import com.simplesdental.product.dto.AuthDTOs;
import com.simplesdental.product.dto.ExceptionResponseDTO;
import com.simplesdental.product.dto.PaginationDTO;
import com.simplesdental.product.dto.ProductDTO;
import com.simplesdental.product.dto.ProductV2DTO;
import com.simplesdental.product.dto.UserDTO;
import com.simplesdental.product.model.Category;
import com.simplesdental.product.model.Product;
import com.simplesdental.product.model.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public class Docs {
    // =================== AUTH CONTROLLER ===================
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface Login {
        @Operation(
                summary = "Autenticação de Usuário",
                description = "Realiza login e retorna token JWT para ser utilizado nas requisições subsequentes",
                tags = {"Autenticação"},
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Credenciais de login do usuário",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = AuthDTOs.AuthRequestDTO.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Exemplo de Credenciais",
                                                summary = "Exemplo básico de credenciais",
                                                value = "{\n  \"email\": \"usuario@exemplo.com\",\n  \"password\": \"senha123\"\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Login realizado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = AuthDTOs.AuthResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Resposta de Sucesso",
                                                        summary = "Exemplo de resposta bem-sucedida",
                                                        value = "{\n  \"token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...\",\n  \"user\": {\n    \"id\": 1,\n    \"name\": \"João Silva\",\n    \"email\": \"usuario@exemplo.com\",\n    \"role\": \"user\"\n  }\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Credenciais inválidas",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        value = "{\n  \"status\": 401,\n  \"message\": \"Falha na autenticação: Credenciais inválidas\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "429",
                                description = "Muitas tentativas de login",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        value = "{\n  \"status\": 429,\n  \"message\": \"Muitas tentativas de login. Tente novamente em 15 minutos.\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface Register {
        @Operation(
                summary = "Registro de Novo Usuário",
                description = "Cria um novo usuário no sistema e retorna token JWT",
                tags = {"Autenticação"},
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Informações do novo usuário",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = AuthDTOs.RegisterRequestDTO.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Registro Básico",
                                                summary = "Exemplo de registro de usuário",
                                                value = "{\n  \"name\": \"João Silva\",\n  \"email\": \"joao.silva@exemplo.com\",\n  \"password\": \"Senha@123\"\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Usuário registrado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = AuthDTOs.AuthResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Resposta de Sucesso",
                                                        summary = "Exemplo de resposta bem-sucedida",
                                                        value = "{\n  \"token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...\",\n  \"user\": {\n    \"id\": 1,\n    \"name\": \"João Silva\",\n    \"email\": \"joao.silva@exemplo.com\",\n    \"role\": \"user\"\n  }\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "400",
                                description = "Informações inválidas para registro",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        value = "{\n  \"status\": 400,\n  \"message\": \"Falha no registro: Email já está em uso\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface GetUserContext {
        @Operation(
                summary = "Obter Contexto do Usuário",
                description = "Recupera informações do usuário autenticado na sessão atual",
                tags = {"Autenticação"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Contexto do usuário recuperado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = UserDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Contexto do Usuário",
                                                        summary = "Informações do usuário logado",
                                                        value = "{\n  \"id\": 1,\n  \"name\": \"João Silva\",\n  \"email\": \"joao.silva@exemplo.com\",\n  \"role\": \"user\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para acessar este recurso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface UpdatePassword {
        @Operation(
                summary = "Atualizar Senha",
                description = "Atualiza a senha do usuário autenticado",
                tags = {"Autenticação"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Senhas atual e nova",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = AuthDTOs.PasswordUpdateDTO.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Atualização de Senha",
                                                value = "{\n  \"currentPassword\": \"senhaAtual123\",\n  \"newPassword\": \"novaSenha123\"\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Senha atualizada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        examples = {
                                                @ExampleObject(
                                                        value = "\"Senha atualizada com sucesso\""
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "400",
                                description = "Senha atual incorreta ou nova senha inválida",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        value = "{\n  \"status\": 400,\n  \"message\": \"Erro ao atualizar senha: Senha atual incorreta\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    // =================== PRODUCTS CONTROLLER ===================
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface ListProducts {
        @Operation(
                summary = "Listar Produtos",
                description = "Recupera lista paginada de produtos com opções de ordenação e filtro",
                tags = {"Produtos"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "page",
                                description = "Número da página (começando em 0)",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "integer", defaultValue = "0")
                        ),
                        @Parameter(
                                name = "size",
                                description = "Tamanho da página",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "integer", defaultValue = "10")
                        ),
                        @Parameter(
                                name = "sort",
                                description = "Critério de ordenação (formato: propriedade,direção - ex: name,asc)",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "string", defaultValue = "createdAt,desc")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Lista de produtos recuperada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = PaginationDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Exemplo de Lista de Produtos",
                                                        value = "{\n  \"content\": [\n    {\n      \"id\": 1,\n      \"name\": \"Produto A\",\n      \"description\": \"Descrição do Produto A\",\n      \"price\": 199.99,\n      \"code\": \"PA001\",\n      \"categoryId\": 1,\n      \"status\": true\n    },\n    {\n      \"id\": 2,\n      \"name\": \"Produto B\",\n      \"description\": \"Descrição do Produto B\",\n      \"price\": 149.90,\n      \"code\": \"PB002\",\n      \"categoryId\": 2,\n      \"status\": true\n    }\n  ],\n  \"page\": 0,\n  \"size\": 10,\n  \"totalElements\": 42\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para listar produtos",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface GetProduct {
        @Operation(
                summary = "Buscar Produto por ID",
                description = "Recupera um produto específico pelo seu identificador único",
                tags = {"Produtos"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID do produto a ser recuperado",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Produto encontrado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = Product.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Produto Encontrado",
                                                        value = "{\n  \"id\": 1,\n  \"name\": \"Produto A\",\n  \"description\": \"Descrição detalhada do Produto A\",\n  \"price\": 199.99,\n  \"code\": \"PA001\",\n  \"category\": {\n    \"id\": 1,\n    \"name\": \"Categoria 1\",\n    \"description\": \"Descrição da Categoria 1\"\n  },\n  \"status\": true,\n  \"createdAt\": \"2025-03-15T14:30:45.123Z\",\n  \"updatedAt\": \"2025-04-05T09:12:30.456Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Produto não encontrado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        value = "{\n  \"status\": 404,\n  \"message\": \"Produto não encontrado com ID: 999\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface CreateProduct {
        @Operation(
                summary = "Criar Novo Produto",
                description = "Adiciona um novo produto ao sistema com base nas informações fornecidas",
                tags = {"Produtos"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Dados do novo produto",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = ProductDTO.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Novo Produto",
                                                value = "{\n  \"name\": \"Produto Novo\",\n  \"description\": \"Descrição do Produto Novo\",\n  \"price\": 299.99,\n  \"code\": \"PN003\",\n  \"categoryId\": 1,\n  \"status\": true\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "201",
                                description = "Produto criado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ProductDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Produto Criado",
                                                        value = "{\n  \"id\": 3,\n  \"name\": \"Produto Novo\",\n  \"description\": \"Descrição do Produto Novo\",\n  \"price\": 299.99,\n  \"code\": \"PN003\",\n  \"categoryId\": 1,\n  \"status\": true\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "400",
                                description = "Dados inválidos ou código de produto duplicado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Código Duplicado",
                                                        value = "{\n  \"status\": 400,\n  \"message\": \"Produto com o código 'PN003' já existe.\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para criar produtos",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface UpdateProduct {
        @Operation(
                summary = "Atualizar Produto",
                description = "Atualiza as informações de um produto existente",
                tags = {"Produtos"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID do produto a ser atualizado",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Dados atualizados do produto",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = Product.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Produto Atualizado",
                                                value = "{\n  \"name\": \"Produto A Atualizado\",\n  \"description\": \"Nova descrição do Produto A\",\n  \"price\": 249.99,\n  \"code\": \"PA001\",\n  \"category\": {\n    \"id\": 2\n  },\n  \"status\": true\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Produto atualizado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ProductDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Resposta de Atualização",
                                                        value = "{\n  \"id\": 1,\n  \"name\": \"Produto A Atualizado\",\n  \"description\": \"Nova descrição do Produto A\",\n  \"price\": 249.99,\n  \"code\": \"PA001\",\n  \"categoryId\": 2,\n  \"status\": true\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "400",
                                description = "Dados inválidos ou código de produto duplicado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Produto não encontrado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para atualizar produtos",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface DeleteProduct {
        @Operation(
                summary = "Excluir Produto",
                description = "Remove um produto do sistema pelo seu identificador",
                tags = {"Produtos"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID do produto a ser excluído",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "204",
                                description = "Produto excluído com sucesso"
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Produto não encontrado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para excluir produtos",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "409",
                                description = "Produto não pode ser excluído devido a dependências",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface ListProductsByCategory {
        @Operation(
                summary = "Listar Produtos por Categoria",
                description = "Recupera lista paginada de produtos de uma categoria específica",
                tags = {"Produtos"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "categoryId",
                                description = "ID da categoria para filtrar os produtos",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        ),
                        @Parameter(
                                name = "page",
                                description = "Número da página (começando em 0)",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "integer", defaultValue = "0")
                        ),
                        @Parameter(
                                name = "size",
                                description = "Tamanho da página",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "integer", defaultValue = "10")
                        ),
                        @Parameter(
                                name = "sort",
                                description = "Critério de ordenação (formato: propriedade,direção - ex: name,asc)",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "string", defaultValue = "createdAt,desc")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Lista de produtos da categoria recuperada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = PaginationDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Produtos de uma Categoria",
                                                        value = "{\n  \"content\": [\n    {\n      \"id\": 1,\n      \"name\": \"Produto A\",\n      \"description\": \"Descrição do Produto A\",\n      \"price\": 199.99,\n      \"code\": \"PA001\",\n      \"categoryId\": 1,\n      \"status\": true\n    },\n    {\n      \"id\": 3,\n      \"name\": \"Produto C\",\n      \"description\": \"Descrição do Produto C\",\n      \"price\": 299.99,\n      \"code\": \"PC003\",\n      \"categoryId\": 1,\n      \"status\": true\n    }\n  ],\n  \"page\": 0,\n  \"size\": 10,\n  \"totalElements\": 15\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Categoria não encontrada",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    // =================== PRODUCTS V2 CONTROLLER ===================
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface ListProductsV2 {
        @Operation(
                summary = "Listar Produtos (Versão 2)",
                description = "Recupera lista paginada de produtos com esquema de resposta aprimorado e informações adicionais",
                tags = {"Produtos V2"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "page",
                                description = "Número da página (começando em 0)",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "integer", defaultValue = "0")
                        ),
                        @Parameter(
                                name = "size",
                                description = "Tamanho da página",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "integer", defaultValue = "10")
                        ),
                        @Parameter(
                                name = "sort",
                                description = "Critério de ordenação (formato: propriedade,direção - ex: name,asc)",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "string", defaultValue = "createdAt,desc")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Lista de produtos recuperada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = PaginationDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Exemplo de Lista de Produtos V2",
                                                        value = "{\n  \"content\": [\n    {\n      \"id\": 1,\n      \"name\": \"Produto A\",\n      \"description\": \"Descrição do Produto A\",\n      \"price\": 199.99,\n      \"code\": \"PA001\",\n      \"category\": {\n        \"id\": 1,\n        \"name\": \"Categoria 1\"\n      },\n      \"status\": true,\n      \"createdAt\": \"2025-03-15T14:30:45.123Z\",\n      \"updatedAt\": \"2025-04-05T09:12:30.456Z\"\n    },\n    {\n      \"id\": 2,\n      \"name\": \"Produto B\",\n      \"description\": \"Descrição do Produto B\",\n      \"price\": 149.90,\n      \"code\": \"PB002\",\n      \"category\": {\n        \"id\": 2,\n        \"name\": \"Categoria 2\"\n      },\n      \"status\": true,\n      \"createdAt\": \"2025-03-18T11:20:15.789Z\",\n      \"updatedAt\": \"2025-04-06T14:25:10.123Z\"\n    }\n  ],\n  \"page\": 0,\n  \"size\": 10,\n  \"totalElements\": 42\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para listar produtos",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface GetProductV2 {
        @Operation(
                summary = "Buscar Produto por ID (Versão 2)",
                description = "Recupera um produto específico pelo seu identificador único com esquema de resposta aprimorado",
                tags = {"Produtos V2"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID do produto a ser recuperado",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Produto encontrado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ProductV2DTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Produto Encontrado V2",
                                                        value = "{\n  \"id\": 1,\n  \"name\": \"Produto A\",\n  \"description\": \"Descrição detalhada do Produto A\",\n  \"price\": 199.99,\n  \"code\": \"PA001\",\n  \"category\": {\n    \"id\": 1,\n    \"name\": \"Categoria 1\",\n    \"description\": \"Descrição da Categoria 1\"\n  },\n  \"status\": true,\n  \"metadata\": {\n    \"createdAt\": \"2025-03-15T14:30:45.123Z\",\n    \"updatedAt\": \"2025-04-05T09:12:30.456Z\"\n  }\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Produto não encontrado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    // =================== CATEGORIES CONTROLLER ===================
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface ListCategories {
        @Operation(
                summary = "Listar Categorias",
                description = "Recupera lista paginada de categorias com opções de ordenação e filtro",
                tags = {"Categorias"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "page",
                                description = "Número da página (começando em 0)",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "integer", defaultValue = "0")
                        ),
                        @Parameter(
                                name = "size",
                                description = "Tamanho da página",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "integer", defaultValue = "10")
                        ),
                        @Parameter(
                                name = "sort",
                                description = "Critério de ordenação (formato: propriedade,direção - ex: name,asc)",
                                in = ParameterIn.QUERY,
                                schema = @Schema(type = "string", defaultValue = "createdAt,desc")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Lista de categorias recuperada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = PaginationDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Exemplo de Lista de Categorias",
                                                        value = "{\n  \"content\": [\n    {\n      \"id\": 1,\n      \"name\": \"Categoria 1\",\n      \"description\": \"Descrição da Categoria 1\",\n      \"createdAt\": \"2025-01-15T10:30:45.123Z\",\n      \"updatedAt\": \"2025-02-05T14:12:30.456Z\"\n    },\n    {\n      \"id\": 2,\n      \"name\": \"Categoria 2\",\n      \"description\": \"Descrição da Categoria 2\",\n      \"createdAt\": \"2025-01-18T11:20:15.789Z\",\n      \"updatedAt\": \"2025-02-06T15:25:10.123Z\"\n    }\n  ],\n  \"page\": 0,\n  \"size\": 10,\n  \"totalElements\": 8\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para listar categorias",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface GetCategory {
        @Operation(
                summary = "Buscar Categoria por ID",
                description = "Recupera uma categoria específica pelo seu identificador único",
                tags = {"Categorias"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID da categoria a ser recuperada",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Categoria encontrada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = Category.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Categoria Encontrada",
                                                        value = "{\n  \"id\": 1,\n  \"name\": \"Categoria 1\",\n  \"description\": \"Descrição detalhada da Categoria 1\",\n  \"createdAt\": \"2025-01-15T10:30:45.123Z\",\n  \"updatedAt\": \"2025-02-05T14:12:30.456Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Categoria não encontrada",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        value = "{\n  \"status\": 404,\n  \"message\": \"Categoria não encontrada com ID: 999\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface CreateCategory {
        @Operation(
                summary = "Criar Nova Categoria",
                description = "Adiciona uma nova categoria ao sistema",
                tags = {"Categorias"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Dados da nova categoria",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = Category.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Nova Categoria",
                                                value = "{\n  \"name\": \"Nova Categoria\",\n  \"description\": \"Descrição da Nova Categoria\"\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "201",
                                description = "Categoria criada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = Category.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Categoria Criada",
                                                        value = "{\n  \"id\": 9,\n  \"name\": \"Nova Categoria\",\n  \"description\": \"Descrição da Nova Categoria\",\n  \"createdAt\": \"2025-04-09T10:15:30.123Z\",\n  \"updatedAt\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "400",
                                description = "Dados inválidos ou categoria com nome duplicado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Nome Duplicado",
                                                        value = "{\n  \"status\": 400,\n  \"message\": \"Categoria com o nome 'Nova Categoria' já existe.\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para criar categorias",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface UpdateCategory {
        @Operation(
                summary = "Atualizar Categoria",
                description = "Atualiza as informações de uma categoria existente",
                tags = {"Categorias"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID da categoria a ser atualizada",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Dados atualizados da categoria",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = Category.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Categoria Atualizada",
                                                value = "{\n  \"name\": \"Categoria 1 Atualizada\",\n  \"description\": \"Nova descrição da Categoria 1\"\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Categoria atualizada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = Category.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Resposta de Atualização",
                                                        value = "{\n  \"id\": 1,\n  \"name\": \"Categoria 1 Atualizada\",\n  \"description\": \"Nova descrição da Categoria 1\",\n  \"createdAt\": \"2025-01-15T10:30:45.123Z\",\n  \"updatedAt\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "400",
                                description = "Dados inválidos ou categoria com nome duplicado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Categoria não encontrada",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para atualizar categorias",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface DeleteCategory {
        @Operation(
                summary = "Excluir Categoria",
                description = "Remove uma categoria do sistema pelo seu identificador",
                tags = {"Categorias"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID da categoria a ser excluída",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "204",
                                description = "Categoria excluída com sucesso"
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Categoria não encontrada",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para excluir categorias",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "409",
                                description = "Categoria não pode ser excluída devido a produtos associados",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        value = "{\n  \"status\": 409,\n  \"message\": \"Não é possível excluir a categoria pois existem produtos associados a ela\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        )
                }
        )
        String value() default "";
    }

    // =================== USERS CONTROLLER ===================
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface ListUsers {
        @Operation(
                summary = "Listar Usuários",
                description = "Recupera lista de todos os usuários (apenas para administradores)",
                tags = {"Usuários"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Lista de usuários recuperada com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        array = @ArraySchema(schema = @Schema(implementation = UserDTO.class)),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Lista de Usuários",
                                                        value = "[\n  {\n    \"id\": 1,\n    \"name\": \"Admin\",\n    \"email\": \"admin@exemplo.com\",\n    \"role\": \"admin\"\n  },\n  {\n    \"id\": 2,\n    \"name\": \"João Silva\",\n    \"email\": \"joao.silva@exemplo.com\",\n    \"role\": \"user\"\n  },\n  {\n    \"id\": 3,\n    \"name\": \"Maria Oliveira\",\n    \"email\": \"maria.oliveira@exemplo.com\",\n    \"role\": \"user\"\n  }\n]"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para listar usuários (apenas admin)",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface GetUser {
        @Operation(
                summary = "Buscar Usuário por ID",
                description = "Recupera um usuário específico pelo seu identificador (apenas para administradores)",
                tags = {"Usuários"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID do usuário a ser recuperado",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Usuário encontrado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = UserDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Usuário Encontrado",
                                                        value = "{\n  \"id\": 2,\n  \"name\": \"João Silva\",\n  \"email\": \"joao.silva@exemplo.com\",\n  \"role\": \"user\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Usuário não encontrado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para visualizar usuários (apenas admin)",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface CreateUser {
        @Operation(
                summary = "Criar Novo Usuário",
                description = "Adiciona um novo usuário ao sistema (apenas para administradores)",
                tags = {"Usuários"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Dados do novo usuário",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = User.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Novo Usuário",
                                                value = "{\n  \"name\": \"Novo Usuário\",\n  \"email\": \"novo.usuario@exemplo.com\",\n  \"password\": \"Senha@123\",\n  \"role\": \"user\"\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "201",
                                description = "Usuário criado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = UserDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Usuário Criado",
                                                        value = "{\n  \"id\": 4,\n  \"name\": \"Novo Usuário\",\n  \"email\": \"novo.usuario@exemplo.com\",\n  \"role\": \"user\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "400",
                                description = "Dados inválidos ou email já em uso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Email Duplicado",
                                                        value = "{\n  \"status\": 400,\n  \"message\": \"Erro ao criar usuário: Email já está em uso: novo.usuario@exemplo.com\",\n  \"timestamp\": \"2025-04-09T10:15:30.123Z\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para criar usuários (apenas admin)",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface UpdateUser {
        @Operation(
                summary = "Atualizar Usuário",
                description = "Atualiza as informações de um usuário existente (apenas para administradores)",
                tags = {"Usuários"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID do usuário a ser atualizado",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        description = "Dados atualizados do usuário",
                        required = true,
                        content = @Content(
                                mediaType = "application/json",
                                schema = @Schema(implementation = User.class),
                                examples = {
                                        @ExampleObject(
                                                name = "Usuário Atualizado",
                                                value = "{\n  \"name\": \"João Silva Atualizado\",\n  \"email\": \"joao.silva@exemplo.com\",\n  \"role\": \"user\"\n}"
                                        )
                                }
                        )
                ),
                responses = {
                        @ApiResponse(
                                responseCode = "200",
                                description = "Usuário atualizado com sucesso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = UserDTO.class),
                                        examples = {
                                                @ExampleObject(
                                                        name = "Resposta de Atualização",
                                                        value = "{\n  \"id\": 2,\n  \"name\": \"João Silva Atualizado\",\n  \"email\": \"joao.silva@exemplo.com\",\n  \"role\": \"user\"\n}"
                                                )
                                        }
                                )
                        ),
                        @ApiResponse(
                                responseCode = "400",
                                description = "Dados inválidos ou email já em uso",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Usuário não encontrado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para atualizar usuários (apenas admin)",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface DeleteUser {
        @Operation(
                summary = "Excluir Usuário",
                description = "Remove um usuário do sistema pelo seu identificador (apenas para administradores)",
                tags = {"Usuários"},
                security = {@SecurityRequirement(name = "bearerAuth")},
                parameters = {
                        @Parameter(
                                name = "id",
                                description = "ID do usuário a ser excluído",
                                in = ParameterIn.PATH,
                                required = true,
                                schema = @Schema(type = "integer", format = "int64")
                        )
                },
                responses = {
                        @ApiResponse(
                                responseCode = "204",
                                description = "Usuário excluído com sucesso"
                        ),
                        @ApiResponse(
                                responseCode = "404",
                                description = "Usuário não encontrado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "401",
                                description = "Não autenticado",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "403",
                                description = "Sem permissão para excluir usuários (apenas admin)",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        ),
                        @ApiResponse(
                                responseCode = "409",
                                description = "Não é possível excluir o usuário (ex: último admin)",
                                content = @Content(
                                        mediaType = "application/json",
                                        schema = @Schema(implementation = ExceptionResponseDTO.class)
                                )
                        )
                }
        )
        String value() default "";
    }
}