package com.simplesdental.product.utils;

import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.examples.Example;
import io.swagger.v3.oas.models.parameters.RequestBody;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import io.swagger.v3.oas.models.security.SecurityRequirement;

import java.util.Collections;

/**
 * Classe para definir a documentação Swagger do ProductController
 * Usa exclusivamente classes do pacote io.swagger.v3.oas.models
 */
public class ProductControllerDocs {

    public static final class ListProducts {
        public static Operation operation() {
            // Criar exemplo de resposta bem-sucedida
            Example successResponseExample = new Example()
                    .description("Exemplo de lista paginada de produtos")
                    .value("{\n  \"content\": [\n    {\n      \"id\": 1,\n      \"name\": \"Produto Exemplo\",\n      \"description\": \"Descrição do produto\",\n      \"price\": 99.90,\n      \"status\": true,\n      \"code\": 12345,\n      \"category\": {\n        \"id\": 1,\n        \"name\": \"Categoria Exemplo\"\n      }\n    }\n  ],\n  \"page\": 0,\n  \"size\": 10,\n  \"totalElements\": 1\n}");

            // Schema para response
            Schema<?> responseSchema = new Schema<>()
                    .$ref("#/components/schemas/PaginationDTO");

            // Criar content para resposta 200
            MediaType successMediaType = new MediaType()
                    .schema(responseSchema)
                    .addExamples("Lista de Produtos", successResponseExample);

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("200", new ApiResponse()
                            .description("Lista paginada de produtos recuperada com sucesso")
                            .content(new Content().addMediaType("application/json", successMediaType)));

            // Criar requisito de segurança
            SecurityRequirement security = new SecurityRequirement().addList("bearerAuth");

            // Criar e retornar a operação
            return new Operation()
                    .summary("Recuperar lista paginada de produtos")
                    .description("Retorna uma lista paginada de todos os produtos disponíveis")
                    .tags(Collections.singletonList("Produtos"))
                    .security(Collections.singletonList(security))
                    .responses(responses);
        }
    }

    public static final class GetProduct {
        public static Operation operation() {
            // Criar exemplo de resposta bem-sucedida
            Example successResponseExample = new Example()
                    .description("Exemplo de produto")
                    .value("{\n  \"id\": 1,\n  \"name\": \"Produto Exemplo\",\n  \"description\": \"Descrição do produto\",\n  \"price\": 99.90,\n  \"status\": true,\n  \"code\": 12345,\n  \"category\": {\n    \"id\": 1,\n    \"name\": \"Categoria Exemplo\"\n  }\n}");

            // Schema para response
            Schema<?> responseSchema = new Schema<>()
                    .$ref("#/components/schemas/Product");

            // Schema para erro
            Schema<?> errorSchema = new Schema<>()
                    .$ref("#/components/schemas/ExceptionResponseDTO");

            // Criar content para resposta 200
            MediaType successMediaType = new MediaType()
                    .schema(responseSchema)
                    .addExamples("Produto", successResponseExample);

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("200", new ApiResponse()
                            .description("Produto encontrado com sucesso")
                            .content(new Content().addMediaType("application/json", successMediaType)))
                    .addApiResponse("404", new ApiResponse()
                            .description("Produto não encontrado"));

            // Criar requisito de segurança
            SecurityRequirement security = new SecurityRequirement().addList("bearerAuth");

            // Criar e retornar a operação
            return new Operation()
                    .summary("Buscar produto por identificador único")
                    .description("Recupera um produto específico pelo seu ID")
                    .tags(Collections.singletonList("Produtos"))
                    .security(Collections.singletonList(security))
                    .responses(responses);
        }
    }

    public static final class CreateProduct {
        public static Operation operation() {
            // Criar exemplo de produto
            Example productExample = new Example()
                    .description("Exemplo de criação de produto")
                    .value("{\n  \"name\": \"Novo Produto\",\n  \"description\": \"Descrição do novo produto\",\n  \"price\": 129.90,\n  \"status\": true,\n  \"code\": 54321,\n  \"category\": {\n    \"id\": 1\n  }\n}");

            // Criar exemplo de resposta bem-sucedida
            Example successResponseExample = new Example()
                    .description("Exemplo de resposta bem-sucedida")
                    .value("{\n  \"id\": 2,\n  \"name\": \"Novo Produto\",\n  \"description\": \"Descrição do novo produto\",\n  \"price\": 129.90,\n  \"status\": true,\n  \"code\": 54321\n}");

            // Criar exemplo de erro de validação
            Example validationErrorExample = new Example()
                    .description("Erro de validação")
                    .value("Produto com o código '54321' já existe.");

            // Schema para request
            Schema<?> requestSchema = new Schema<>()
                    .$ref("#/components/schemas/ProductDTO");

            // Schema para response
            Schema<?> responseSchema = new Schema<>()
                    .$ref("#/components/schemas/ProductDTO");

            // Criar o content para request body
            MediaType requestMediaType = new MediaType()
                    .schema(requestSchema)
                    .addExamples("Produto Básico", productExample);

            // Criar request body
            RequestBody requestBody = new RequestBody()
                    .description("Informações do novo produto")
                    .required(true)
                    .content(new Content().addMediaType("application/json", requestMediaType));

            // Criar content para resposta 201
            MediaType createdMediaType = new MediaType()
                    .schema(responseSchema)
                    .addExamples("Produto Criado", successResponseExample);

            // Criar content para resposta 400
            MediaType badRequestMediaType = new MediaType()
                    .addExamples("default", validationErrorExample);

            // Criar content para resposta 500
            MediaType serverErrorMediaType = new MediaType()
                    .addExamples("default", new Example()
                            .value("Erro interno: Falha ao processar a requisição"));

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("201", new ApiResponse()
                            .description("Produto criado com sucesso")
                            .content(new Content().addMediaType("application/json", createdMediaType)))
                    .addApiResponse("400", new ApiResponse()
                            .description("Dados inválidos ou produto com código duplicado")
                            .content(new Content().addMediaType("application/json", badRequestMediaType)))
                    .addApiResponse("500", new ApiResponse()
                            .description("Erro interno no servidor")
                            .content(new Content().addMediaType("application/json", serverErrorMediaType)));

            // Criar requisito de segurança
            SecurityRequirement security = new SecurityRequirement().addList("bearerAuth");

            // Criar e retornar a operação
            return new Operation()
                    .summary("Criar um novo produto")
                    .description("Cria um novo produto no sistema")
                    .tags(Collections.singletonList("Produtos"))
                    .security(Collections.singletonList(security))
                    .requestBody(requestBody)
                    .responses(responses);
        }
    }

    public static final class UpdateProduct {
        public static Operation operation() {
            // Criar exemplo de atualização de produto
            Example productUpdateExample = new Example()
                    .description("Exemplo de atualização de produto")
                    .value("{\n  \"name\": \"Produto Atualizado\",\n  \"description\": \"Nova descrição do produto\",\n  \"price\": 149.90,\n  \"status\": true,\n  \"code\": 12345,\n  \"category\": {\n    \"id\": 1\n  }\n}");

            // Criar exemplo de resposta bem-sucedida
            Example successResponseExample = new Example()
                    .description("Exemplo de resposta bem-sucedida")
                    .value("{\n  \"id\": 1,\n  \"name\": \"Produto Atualizado\",\n  \"description\": \"Nova descrição do produto\",\n  \"price\": 149.90,\n  \"status\": true,\n  \"code\": 12345\n}");

            // Criar exemplo de erro
            Example errorExample = new Example()
                    .description("Erro ao atualizar")
                    .value("Produto não encontrado com ID: 1");

            // Schema para request
            Schema<?> requestSchema = new Schema<>()
                    .$ref("#/components/schemas/Product");

            // Schema para response
            Schema<?> responseSchema = new Schema<>()
                    .$ref("#/components/schemas/ProductDTO");

            // Criar o content para request body
            MediaType requestMediaType = new MediaType()
                    .schema(requestSchema)
                    .addExamples("Atualização de Produto", productUpdateExample);

            // Criar request body
            RequestBody requestBody = new RequestBody()
                    .description("Informações atualizadas do produto")
                    .required(true)
                    .content(new Content().addMediaType("application/json", requestMediaType));

            // Criar content para resposta 200
            MediaType successMediaType = new MediaType()
                    .schema(responseSchema)
                    .addExamples("Produto Atualizado", successResponseExample);

            // Criar content para resposta 400
            MediaType badRequestMediaType = new MediaType()
                    .addExamples("default", errorExample);

            // Criar content para resposta 500
            MediaType serverErrorMediaType = new MediaType()
                    .addExamples("default", new Example()
                            .value("Erro interno: Falha ao processar a requisição"));

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("200", new ApiResponse()
                            .description("Produto atualizado com sucesso")
                            .content(new Content().addMediaType("application/json", successMediaType)))
                    .addApiResponse("400", new ApiResponse()
                            .description("Dados inválidos ou produto não encontrado")
                            .content(new Content().addMediaType("application/json", badRequestMediaType)))
                    .addApiResponse("500", new ApiResponse()
                            .description("Erro interno no servidor")
                            .content(new Content().addMediaType("application/json", serverErrorMediaType)));

            // Criar requisito de segurança
            SecurityRequirement security = new SecurityRequirement().addList("bearerAuth");

            // Criar e retornar a operação
            return new Operation()
                    .summary("Atualizar um produto existente")
                    .description("Atualiza as informações de um produto existente")
                    .tags(Collections.singletonList("Produtos"))
                    .security(Collections.singletonList(security))
                    .requestBody(requestBody)
                    .responses(responses);
        }
    }

    public static final class DeleteProduct {
        public static Operation operation() {
            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("204", new ApiResponse()
                            .description("Produto excluído com sucesso"))
                    .addApiResponse("404", new ApiResponse()
                            .description("Produto não encontrado"));

            // Criar requisito de segurança
            SecurityRequirement security = new SecurityRequirement().addList("bearerAuth");

            // Criar e retornar a operação
            return new Operation()
                    .summary("Remover um produto pelo seu identificador")
                    .description("Exclui um produto do sistema")
                    .tags(Collections.singletonList("Produtos"))
                    .security(Collections.singletonList(security))
                    .responses(responses);
        }
    }

    public static final class ListProductsByCategory {
        public static Operation operation() {
            // Criar exemplo de resposta bem-sucedida
            Example successResponseExample = new Example()
                    .description("Exemplo de lista paginada de produtos por categoria")
                    .value("{\n  \"content\": [\n    {\n      \"id\": 1,\n      \"name\": \"Produto Exemplo\",\n      \"description\": \"Descrição do produto\",\n      \"price\": 99.90,\n      \"status\": true,\n      \"code\": 12345,\n      \"category\": {\n        \"id\": 1,\n        \"name\": \"Categoria Exemplo\"\n      }\n    }\n  ],\n  \"page\": 0,\n  \"size\": 10,\n  \"totalElements\": 1\n}");

            // Schema para response
            Schema<?> responseSchema = new Schema<>()
                    .$ref("#/components/schemas/PaginationDTO");

            // Criar content para resposta 200
            MediaType successMediaType = new MediaType()
                    .schema(responseSchema)
                    .addExamples("Lista de Produtos por Categoria", successResponseExample);

            // Criar as respostas
            ApiResponses responses = new ApiResponses()
                    .addApiResponse("200", new ApiResponse()
                            .description("Lista paginada de produtos por categoria recuperada com sucesso")
                            .content(new Content().addMediaType("application/json", successMediaType)));

            // Criar requisito de segurança
            SecurityRequirement security = new SecurityRequirement().addList("bearerAuth");

            // Criar e retornar a operação
            return new Operation()
                    .summary("Recuperar produtos por categoria")
                    .description("Retorna uma lista paginada de produtos filtrados por categoria")
                    .tags(Collections.singletonList("Produtos"))
                    .security(Collections.singletonList(security))
                    .responses(responses);
        }
    }
}